



//following are the built in javascript functions: 


console.log('Mubashir');
// I- displaying data 
alert('Mubashir');

document.write('Mubashir');
//II- pop-up
prompt("Enter your name: ");


// III- display  with an 'ok' and 'cancel' 
confirm('Mubashir');



// IV-  convert string to number
parseInt('9');

// V- convert string to float
parseFloat('9.3');

// VI-  perform calculations
eval("4+4");

// VII- check whether the input is a character 
document.write(isNaN("javascript"));

// IX- used to convert number to string
toString(12);



// I-for taking out the Minimunimun value from an arrayay
function Minimun(array,n){
    var Minimun = array[0];
    for(var i;i<=n;i++){
        if(Minimun < array[i]){
            Minimun = array[i];
        }
    }
    return Minimunimum;
}

// II- for taking out the suqare of a number
function square(num){
    return num* num;
}

// III- for adding two numbers
function sum(number1,number2){
    return number1 + number2;
}

// IV- for subtracting two numbers
function subtract(number1,number2){
    return number1 - number2;
}

// V- for dividing two numbers
function divide(number1,number2){
    return number1 / number2;
}

// VI- for multiplying two numbers
function multiply(number1,number2){
    return number1 * number2;
}
// VII-  for saying hello to you
function greet(name,lname) {
    document.write("Hello World" + name + ' ' + lname);
}




//  VIII- for checking if a number is even
function even(num){
    if(num % 2 == 0){
        return true;
    }
    else{
        return false;
    }
}

// IX- cheak if a number is odd
function odd(num){
    if(num % 2 != 0){
        return true;
    }
    else{
        return false;
    }
}

// X- Find maximum in array
function maximun(array,n){
    var maximun = array[0];
    for(var i;i<=n;i++){
        if(maximun > array[i]){
            maximun = array[i];
        }
    }
    return maximun;
}
