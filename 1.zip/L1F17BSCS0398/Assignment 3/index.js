//Following are the user defined functions

// for saying hello to you
function greet(name,lname) {
    document.write("Hello World" + name + ' ' + lname);
}

//for taking out the suqare of a number
function square(num){
    return num* num;
}

//for adding two numbers
function sum(num1,num2){
    return num1 + num2;
}

//for subtracting two numbers
function subtract(num1,num2){
    return num1 - num2;
}

//for dividing two numbers
function divide(num1,num2){
    return num1 / num2;
}

//for multiplying two numbers
function multiply(num1,num2){
    return num1 * num2;
}

//for taking out the minimun value from an array
function min(arr,size){
    var min = arr[0];
    for(var i;i<=size;i++){
        if(min < arr[i]){
            min = arr[i];
        }
    }
    return min;
}

//for taking out the maximum value from an array
function max(arr,size){
    var max = arr[0];
    for(var i;i<=size;i++){
        if(max > arr[i]){
            max = arr[i];
        }
    }
    return max;
}

// for checking if a number is even
function even(num){
    if(num % 2 == 0){
        return true;
    }
    else{
        return false;
    }
}

//for checking if a number is odd
function odd(num){
    if(num % 2 != 0){
        return true;
    }
    else{
        return false;
    }
}


//following are the built in javascript functions: 

//used for diaplaying data in console:
console.log('kiran');

//used for displaying data on screen:
document.write('kiran');

//used for displaying data as a pop up in the middle of the screen
alert('kiran');

//used to display the same as alert but with an 'ok' and 'cancel' option
confirm('kiran');

//takes input from user in a pop-up dialogue box
prompt("Enter your name: ");

//used to convert string to number
parseInt('9');

//used to convert string to float(a value having decimal places)
parseFloat('9.3');

//used to perform calculations
eval("4+4");

//used to check whether the inpur is a character or not
document.write(isNaN("javascript"));

//used to convert number to string
toString(9);